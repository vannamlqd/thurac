<ul class="nav">
    <li><a href="{{route('indexEmail')}}">Danh sách địa chỉ Email</a>
    <li><a href="{{route('indexsender')}}">Danh sách người gửi</a>
    </li>
    <li><a href="{{route('indexip')}}">Danh sách địa chỉ Ip</a>
    </li>
    <li><a href="{{route('indexdomain')}}">Danh sách địa chỉ domain</a>
    </li>
    <li><a href="{{route('indexreport')}}">Xác thực thư rác từ cảnh báo người dùng</a>
    </li>
   <!--  <li><a href="#">Thống kê</a>
    </li> -->
</ul>