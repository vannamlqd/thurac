<ul class="nav">
    <li><a href="{{route('indextype')}}">Phân loại thư rác</a></li>
    <li><a href="{{route('indexorigin')}}">Nguồn thu thập</a></li>
</ul>