@extends('admin.layoutmaster')
@section('active')
@include('Email::active')
@endsection
@section('content')
<div class="panel panel-primary">
<div class="panel-heading">
    <span>Báo cáo, thống kê </span>
    <!-- <a href="{{route('addemail')}}" class="add">Thêm mới</a> -->
    <div class="clear"></div>
</div>
<div class="panel-body">
  <!-- Nav tabs -->
  <ul class="nav nav-tabs" role="tablist">
    <li role="presentation" class="active"><a href="#statistic" aria-controls="statistic" role="tab" data-toggle="tab">Thống kê</a></li>
    <li role="presentation"><a href="#report" aria-controls="report" role="tab" data-toggle="tab">Báo cáo</a></li>
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
    <div role="tabpanel" class="tab-pane active mb row" id="statistic" >
    	<form action="" class="form-inline" method="" role="form">
	    {{ csrf_field() }}
	    <div class="form-group col-md-4">
	    	<label for="from">Từ</label>
	        <input placeholder="dd/mm/yy" type="text" name="" class="form-control date"  value="" id="from">
	    </div>
	    <div class="form-group col-md-4">
	    	<label for="to">Đến</label>
	        <input placeholder="dd/mm/yy" type="text" name="" class="form-control date"  value="" id="to">
	    </div>
		<div class="col-md-4">
			<button type="submit" class="btn btn-primary">Hiển Thị</button>
		</div>
	    </form>

    </div>
    <div role="tabpanel" class="tab-pane mb" id="report">
    	Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia, amet!
    </div>
  </div>

</div>
</div>
@endsection