@extends('admin.layoutmaster')
@section('active')
@include('Email::active2')
@endsection
@section('content')
<div class="panel panel-primary">
<div class="panel-heading">
    <span>Danh sách luật phân loại thư rác</span>
    <a href="" class="add">Thêm luật phân loại thư rác</a>
    <div class="clear"></div>
</div>
<div class="panel-body">
    @include('errors.showerr')
    <div class="wtable">
		<table class="table table-bordered">
		<thead class="danger">
		<tr class="danger">
		<th class="text-center" >Tên nhóm</th>
		<th class="text-center" >Luật nhận dạng</th>
		<th class="text-center" >Tình trạng</th>
		<th class="text-center">Hành động</th>
		</tr>
		</thead>
		<tbody><tr>
		<td align="center"> malware</td>
		<td align="left"><code>Body =~ #Không được sửa#<br>
		</code>								</td>
		<td align="center"> <a class="glyphicon glyphicon-ok" style="color:green" href="http://103.28.173.237/spamdetect/changestatus?id=18&amp;action=disable">
		</a>
		</td>
		<td align="center">
		</td>
		</tr>
		<tr class="even ">
		<td align="center"> Thư rác quảng cáo bán nhà</td>
		<td align="left"><code>Body =~ Bán chung cư<br>
		Body =~ Bán nhà<br>
		</code>								</td>
		<td align="center"> <a class="glyphicon glyphicon-ok" style="color:green" href="http://103.28.173.237/spamdetect/changestatus?id=21&amp;action=disable">
		</a>
		</td>
		<td align="center">
		<a href="http://103.28.173.237/spamdetect/edit?id=21">Sửa</a>
		<a href="http://103.28.173.237/spamdetect/delete?id=21"> / Xóa</a>
		</td>
		</tr>
		<tr class="even ">
		<td align="center"> Thư chứa nội dung quảng cáo</td>
		<td align="left"><code>Body =~ bạn<br>
		Body =~ tôi<br>
		Body =~ muốn có<br>
		Body =~ thành công<br>
		Body =~ triệu phú<br>
		Body =~ tỷ phú<br>
		Body =~ muốn<br>
		</code>								</td>
		<td align="center"> <a class="glyphicon glyphicon-ok" style="color:green" href="http://103.28.173.237/spamdetect/changestatus?id=27&amp;action=disable">
		</a>
		</td>
		<td align="center">
		<a href="http://103.28.173.237/spamdetect/edit?id=27">Sửa</a>
		<a href="http://103.28.173.237/spamdetect/delete?id=27"> / Xóa</a>
		</td>
		</tr>
		<tr class="even ">
		<td align="center"> Thư chứa nội dung phản động</td>
		<td align="left"><code>Body =~ Nguyễn Minh Triết<br>
		Body =~ Tô Huy Rứa<br>
		Body =~ Nguyễn Phú Trọng<br>
		Body =~ Nguyễn Xuân Phúc<br>
		Body =~ Nguyền Thiện Nhân<br>
		Body =~ Trương Tấn Sang<br>
		</code>								</td>
		<td align="center"> <a class="glyphicon glyphicon-ok" style="color:green" href="http://103.28.173.237/spamdetect/changestatus?id=25&amp;action=disable">
		</a>
		</td>
		<td align="center">
		<a href="http://103.28.173.237/spamdetect/edit?id=25">Sửa</a>
		<a href="http://103.28.173.237/spamdetect/delete?id=25"> / Xóa</a>
		</td>
		</tr>
		<tr class="even ">
		<td align="center"> Thư chứa nội dung không lành mạnh</td>
		<td align="left"><code>Body =~ porn<br>
		Body =~ sex<br>
		Body =~ penis<br>
		Body =~ pussy<br>
		</code>								</td>
		<td align="center"> <a class="glyphicon glyphicon-ok" style="color:green" href="http://103.28.173.237/spamdetect/changestatus?id=26&amp;action=disable">
		</a>
		</td>
		<td align="center">
		<a href="http://103.28.173.237/spamdetect/edit?id=26">Sửa</a>
		<a href="http://103.28.173.237/spamdetect/delete?id=26"> / Xóa</a>
		</td>
		</tr>
		</tbody></table>
    </div>
</div>
</div>
@endsection