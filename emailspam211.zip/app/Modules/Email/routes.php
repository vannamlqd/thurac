<?php
$namespace = 'App\Modules\Email\Controllers';
Route::group(['module'=>'Email', 'namespace' => $namespace,'middleware' =>'web'], function() {
	
	Route::group(['prefix' => 'admin','middleware'=>'auth'], function() {
		/*Route::get('getgmail',['as'=>'getgmail','uses'=>'EmailController@getGmail']);*/
		Route::get('editorigin.html/{id}',['as'=>'geteditorigin','uses'=>'EmailController@getEditOrigin']);
		Route::post('editorigin.html/{id}',['as'=>'posteditorigin','uses'=>'EmailController@postEditOrigin']);
		Route::get('addorigin.html',['as'=>'getaddorigin','uses'=>'EmailController@getAddOrigin']);
		Route::post('addorigin.html',['as'=>'postaddorigin','uses'=>'EmailController@postAddOrigin']);
		Route::get('getmailimap',['as'=>'getmailimap','uses'=>'EmailController@getMailImap']);
		Route::get('listemail.html', ['as' => 'indexEmail', 'uses' => 'EmailController@index']);
		Route::get('detailemail.html/{id}', ['as' => 'detailemail', 'uses' => 'EmailController@detailEmail']);
		Route::get('listreport.html', ['as' => 'indexreport', 'uses' => 'EmailController@indexreport']);
		Route::get('statistic.html', ['as' => 'indexstatistic', 'uses' => 'EmailController@indexstatistic']);
		Route::get('listorigin.html', ['as' => 'indexorigin', 'uses' => 'EmailController@indexorigin']);
		Route::get('listtype.html', ['as' => 'indextype', 'uses' => 'EmailController@indextype']);
		Route::get('listsender.html', ['as' => 'indexsender', 'uses' => 'EmailController@indexsender']);
		Route::get('listip.html', ['as' => 'indexip', 'uses' => 'EmailController@indexip']);
		Route::get('listdomain.html', ['as' => 'indexdomain', 'uses' => 'EmailController@indexdomain']);
		Route::get('addemail.html', ['as' => 'addemail', 'uses' => 'EmailController@getAdd']);
		Route::post('addemail', ['as' => 'postaddemail', 'uses' => 'EmailController@postAdd']);
		Route::get('editemail.html/{id}', ['as' => 'editemail', 'uses' => 'EmailController@getEdit'])->where('id', '[0-9]+');
		Route::post('editemail.html/{id}', ['as' => 'editemail', 'uses' => 'EmailController@postEdit'])->where('id', '[0-9]+');
		Route::get('dellemail.html/{id}', ['as' => 'dellemail', 'uses' => 'EmailController@dellEmail'])->where('id', '[0-9]+');
		Route::get('setpublicmail/{id}', ['as' => 'publicmail', 'uses' => 'EmailController@setPublicMail'])->where('id', '[0-9]+');

		//csv
		Route::get('csvchoose',['as'=>'csvchoose','uses'=>'EmailController@chooseCsv']);
		Route::post('csvread',['as'=>'csvread','uses'=>'EmailController@importCsv']);
		//ecel export
		Route::get('exportxls/{model}', ['as'=>'exportxls','uses'=>'EmailController@exportxls']);
	});

});
