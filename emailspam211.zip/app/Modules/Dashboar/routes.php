<?php
$namespace = 'App\Modules\Dashboar\Controllers';
Route::group(['module'=>'Dashboar', 'namespace' => $namespace,'middleware' =>'web'], function() {
	Route::group(['prefix' => 'admin','middleware'=>'auth'], function() {
		    Route::get('/',['as'=>'dashboar','uses'=>'DashController@index']);
		});	

});
