<ul class="nav">
	<li><a href="{{route('listUser')}}">Danh sách tài khoản</a></li>
	<li><a href="{{route('addUser')}}">Thêm tài khoản</a></li>
</ul>