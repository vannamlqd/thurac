<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EMail extends Model
{
    protected $table = 'emails';
    protected $guarded = [''];
}