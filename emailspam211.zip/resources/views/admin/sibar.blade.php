<div class="panel panel-primary">
    <div class="panel-heading">Chức năng</div>
    <div class="panel-body">
        @yield('active')
    </div>
</div>
<div class="panel panel-primary">
    <div class="panel-heading">Thống kê</div>
    <div class="panel-body">
        <ul class="list-group" >
        <li class="list-group-item">Tổng thư rác<span class="badge">@if(isset($count['email'])){{ $count['email'] }}@endif</span></li>
        <li class="list-group-item">Địa chỉ Ip<span class="badge">@if(isset($count['ip'])){{ count($count['ip']) }}@endif</span></li>
        <li class="list-group-item">Địa chỉ gửi<span class="badge">@if(isset($count['sender'])){{ count($count['sender']) }}@endif</span></li>
        <li class="list-group-item">Tên miền gửi<span class="badge">@if(isset($count['domain'])){{ count($count['domain']) }}@endif</span></li>
        </ul>
    </div>
</div>