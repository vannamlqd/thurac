<div class="banner">
    
</div>
<div class="menu">
    <nav class="navbar navbar-inverse" id="navtop">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand visible-xs" href="{{route('dashboar')}}">Brand</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav left">
                    <li><a href="{{route('dashboar')}}">Trang chủ</a>
                    </li>
                    <li>
                        <a href="#">Thư rác</a>
                        <ul class="l2">
                            <li>
                                <a href="{{route('indexEmail')}}">Danh sách thư rác</a>
                            </li>
                            <li>
                                <a href="#">Quản lý địa chỉ phát tán thư rác</a>
                                <ul class="l3">
                                   <li><a href="{{route('indexsender')}}">Địa chỉ thư rác</a></li>
                                    <li><a href="{{route('indexip')}}">Địa chỉ IP</a></li>
                                    <li><a href="{{route('indexdomain')}}">Địa chỉ tên miền</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="{{route('indexreport')}}">Xác thực thư rác từ cảnh báo người dùng</a>
                            </li>
                            <li>
                                <a href="{{route('indexstatistic')}}">Báo cáo, thống kê</a>
                            </li>
                        </ul>
                    </li>
                    <li><a href="#">Cấu hình</a>
                    <ul class="l2">
                        <li><a href="{{route('indextype')}}">Phân loại thư rác</a></li>
                        <li><a href="{{route('indexorigin')}}">Nguồn thu thập</a></li>
                    </ul>
                    </li>
                    <li><a href="#">Hệ Thống</a>
                        <ul class="l2">
                            <li>
                                <a href="">Tài khoản</a>
                                <ul class="l3">
                                    <li><a href="{{route('listUser')}}">Danh sách tài khoản</a></li>
                                    <li><a href="{{route('addUser')}}">Thêm tài khoản</a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="user"><a href="#">Xin Chào :@if(Session::has('user'))
                    {{ Session::get('user')->name }}
                    @endif</a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="{{route('logout')}}">Đăng xuất</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</div>