@include('admin.head')
<div class="container">
    @include('admin.menu')
    <div id="wrap">
        <div class="row">
            <div class="col-md-2">
            @include('admin.sibar')
            </div><!-- col-2-->
            <div class="col-md-10">
            @yield('content')
            </div><!-- col-10 -->
        </div>
        <footer>
            <p class="text-center">Copyright by VNCERT</p>
        </footer>
    </div>
</div>
@include('admin.footer')