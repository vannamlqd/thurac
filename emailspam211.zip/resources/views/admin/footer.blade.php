   <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
   <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
   <script>
   	$(document).ready(function() {
   			$(".seemore").click(function(event) {
   				$(this).closest( ".detail" ).find('.more').removeClass('more');
   				$(this).remove();
   			});
   		});	
   </script>
<script>
  $(function() {
     $(".date").datepicker({ dateFormat: "dd-mm-yy" }).val()
  });
</script>
</body>

</html>