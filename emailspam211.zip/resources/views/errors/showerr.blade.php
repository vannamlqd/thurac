<div class="show-message">
	@if(Session::has('bag_message'))
		<div class="alert alert-{{Session::get('bag_level')}}">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<p>{{Session::get('bag_message')}}</p>
		</div>
	@endif
	@if(count($errors)>0)
		<div class="alert alert-danger">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<ul style="margin:0;padding:0 15px">
				@foreach($errors->all() as $e)
					<li>{{$e}}</li>
				@endforeach
			</ul>
		</div>
	@endif
</div>
